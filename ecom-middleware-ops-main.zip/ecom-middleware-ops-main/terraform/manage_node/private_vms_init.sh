#!/bin/bash
# Initialize control node for Kafka VM deployment
# This script prepares the control node with necessary tools and code
# (renamed from private_vmss_init.sh - now using VMs instead of VMSS for better control)

set -e
export DEBIAN_FRONTEND=noninteractive

# Download HashiCorp GPG key and import it (use -O - to stdout, force overwrite with sudo)
wget -O - https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg --yes --batch --no-tty
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update && sudo apt install terraform jq -y

# Explicitly disable UFW to ensure ports 3000/9090 are reachable relative to Azure NSG
sudo ufw disable

sudo DEBIAN_FRONTEND=noninteractive apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y python3-venv

curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

mkdir ansible-venv
python3 -m venv ansible-venv/
source ansible-venv/bin/activate

python3 -m pip install ansible
ansible-galaxy collection install azure.azcollection --force
python3 -m pip install -r ~/.ansible/collections/ansible_collections/azure/azcollection/requirements.txt

ssh-keygen -t rsa -N '' -f ~/.ssh/id_rsa <<< y

token=`curl 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fvault.azure.net' -H Metadata:true | cut -d '"' -f 4`
mysecret=`curl 'https://control-keyvault.vault.azure.net/secrets/github-token?api-version=7.4' -H "Authorization: Bearer $token" | cut -d '"' -f 4`

REPO_URL="https://momodedev:$mysecret@github.com/momodedev/ecom-middleware-ops.git"
REPO_DIR="ecom-middleware-ops"
# Allow overriding branch/tag via GIT_REF; default to main
GIT_REF="${GIT_REF:-main}"

if [ -d "$REPO_DIR/.git" ]; then
	echo "Repository already present, fetching latest from origin ($GIT_REF)..."
	git -C "$REPO_DIR" fetch origin --prune && git -C "$REPO_DIR" checkout "$GIT_REF" && git -C "$REPO_DIR" pull --ff-only origin "$GIT_REF"
else
	echo "Cloning repository (ref: $GIT_REF)..."
	if ! git clone --branch "$GIT_REF" "$REPO_URL" "$REPO_DIR"; then
		echo "Clone failed; exiting" >&2
		exit 1
	fi
fi

echo "Initialization done"

#/var/lib/waagent/custom-script/download/0
